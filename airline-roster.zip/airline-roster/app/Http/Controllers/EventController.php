<?php

namespace App\Http\Controllers;
use App\Models\Event;
use Illuminate\Http\Request;
use Carbon\Carbon;


class EventController extends Controller
{
    public function parseRoster(Request $request)
    {
        // 1. Handle file upload and validation
        $request->validate([
            'roster' => 'required|mimes:pdf,xlsx,csv,txt',
        ]);

        // Get the uploaded file
        $file = $request->file('roster');

        // 2. Read the contents of the roster file
        // Example: Parse events from the file data
        $events = [];
        // Assuming the file is in CSV format for demonstration purposes
        if ($file->getClientOriginalExtension() === 'csv') {
            $fileData = file_get_contents($file->getRealPath());
            $rows = explode("\n", $fileData);
            foreach ($rows as $row) {
                $columns = str_getcsv($row);
                // Assuming the CSV format is: type, flight_number, start_time, end_time
                if (count($columns) >= 4) {
                    $event = [
                        'type' => $columns[0],
                        'flight_number' => $columns[1],
                        'start_time' => Carbon::parse($columns[2]),
                        'end_time' => Carbon::parse($columns[3]),
                        // Add other fields as needed
                    ];
                    $events[] = $event;
                }
            }
        }

        // 3. Store the parsed events in the database
        // Here, you would store the parsed events in the 'events' table
        // Assuming the 'Event' model is correctly set up
        Event::insert($events);

        // Return response indicating success
        return response()->json(['message' => 'Roster parsed successfully'], 200);
    }

    public function getEventsBetweenDates(Request $request)
    {
        // 1. Receive the start and end dates from the request
        $request->validate([
            'start_date' => 'required|date',
            'end_date' => 'required|date|after_or_equal:start_date',
        ]);

        $startDate = $request->input('start_date');
        $endDate = $request->input('end_date');

        // 2. Query the database for events that fall within the specified date range
        $events = Event::whereBetween('start_time', [$startDate, $endDate])
                       ->orWhereBetween('end_time', [$startDate, $endDate])
                       ->get();

        // 3. Return the retrieved events as a JSON response
        return response()->json($events);
    }

    public function getFlightsForNextWeek()
    {
        // 1. Determine the start and end dates for the next week
        $startDate = Carbon::today()->startOfWeek()->addWeek(); // Start of next week
        $endDate = Carbon::today()->startOfWeek()->addWeeks(2)->subDay(); // End of next week

        // 2. Query the database for flights that fall within the specified date range
        $flights = Event::where('type', 'FLT')
                        ->whereBetween('start_time', [$startDate, $endDate])
                        ->get();

        // 3. Return the retrieved flights as a JSON response
        return response()->json($flights);
    }

    public function getStandbyEventsForNextWeek()
    {
        // 1. Determine the start and end dates for the next week
        $startDate = Carbon::today()->startOfWeek()->addWeek(); // Start of next week
        $endDate = Carbon::today()->startOfWeek()->addWeeks(2)->subDay(); // End of next week

        // 2. Query the database for standby events that fall within the specified date range
        $standbyEvents = Event::where('type', 'SBY')
                              ->whereBetween('start_time', [$startDate, $endDate])
                              ->get();

        // 3. Return the retrieved standby events as a JSON response
        return response()->json($standbyEvents);
    }
    
    public function getFlightsByLocation(Request $request)
    {
        // 1. Receive the location from the request
        $request->validate([
            'location' => 'required|string',
        ]);

        $location = $request->input('location');

        // 2. Query the database for flights that start at the specified location
        $flights = Event::where('type', 'FLT')
                        ->where('start_location', $location)
                        ->get();

        // 3. Return the retrieved flights as a JSON response
        return response()->json($flights);
    }


}
