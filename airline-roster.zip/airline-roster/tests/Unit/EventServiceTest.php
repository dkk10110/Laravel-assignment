<?php

namespace Tests\Unit\Services;

use App\Services\EventService;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

class EventServiceTest extends TestCase
{
    public function testParseRosterFile()
    {
        // Create a mock CSV file content
        $fileContent = "DO,2024-03-19 08:00:00,2024-03-19 17:00:00\nFLT,2024-03-20 09:00:00,2024-03-20 10:00:00\n";

        // Mock the file and its path
        Storage::fake('uploads');
        $file = UploadedFile::fake()->createWithContent('roster.csv', $fileContent);

        // Instantiate the EventService
        $eventService = new EventService();

        // Call the parseRosterFile method
        $events = $eventService->parseRosterFile($file);

        // Assert that the parsing logic returns the expected events
        $this->assertCount(2, $events);
        $this->assertEquals('DO', $events[0]['type']);
        $this->assertEquals('2024-03-19 08:00:00', $events[0]['start_time']);
        $this->assertEquals('2024-03-19 17:00:00', $events[0]['end_time']);
        $this->assertEquals('FLT', $events[1]['type']);
        $this->assertEquals('2024-03-20 09:00:00', $events[1]['start_time']);
        $this->assertEquals('2024-03-20 10:00:00', $events[1]['end_time']);
    }
}
