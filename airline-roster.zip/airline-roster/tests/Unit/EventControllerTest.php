<?php

namespace Tests\Feature\Controllers;

use App\Http\Controllers\EventController;
use App\Services\EventService;
use Illuminate\Http\Request;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

class EventControllerTest extends TestCase
{
    public function testParseRoster()
    {
        // Create a mock CSV file content
        $fileContent = "DO,2024-03-19 08:00:00,2024-03-19 17:00:00\nFLT,2024-03-20 09:00:00,2024-03-20 10:00:00\n";

        // Mock the file and its path
        Storage::fake('uploads');
        $file = UploadedFile::fake()->createWithContent('roster.csv', $fileContent);

        // Create a mock request with the file
        $request = Request::create('/parse-roster', 'POST', ['roster' => $file]);

        // Mock the EventService
        $eventServiceMock = $this->createMock(EventService::class);
        $eventServiceMock->expects($this->once())
                         ->method('parseRosterFile')
                         ->willReturn([]);

        // Instantiate the EventController with the mocked service
        $eventController = new EventController($eventServiceMock);

        // Call the parseRoster method with the mocked request
        $response = $eventController->parseRoster($request);

        // Assert that the controller returns the expected response
        $response->assertStatus(200);
    }
}
